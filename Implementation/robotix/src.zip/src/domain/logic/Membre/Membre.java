package domain.logic.Membre;
public class Membre {
    protected String nom;
    protected String adresse;
    protected String email;
    protected String numeroTelephone;
    protected String nomCompagnie;

    public Membre(String nom, String adresse, String email, String numeroTelephone, String nomCompagnie) {
        this.nom = nom;
        this.adresse = adresse;
        this.email = email;
        this.numeroTelephone = numeroTelephone;
        this.nomCompagnie = nomCompagnie;
    }
    
    public static void name() {
        
    }

}
