package domain.logic.Controller;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Controller {

    public void read(String fichierCSV, String index, String colonne) throws IOException{
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Kamen\\ML\\Devoirs-IFT-2255\\Implementation\\robotix\\src\\domain\\logic\\BaseDeDonnees\\test.csv"));
        List<String> lines = new ArrayList<>();
        String line = null;
        while ((line = reader.readLine()) != null) {
            lines.add(line);
        }

        System.out.println(lines.get(1)); 
        } 
    }
